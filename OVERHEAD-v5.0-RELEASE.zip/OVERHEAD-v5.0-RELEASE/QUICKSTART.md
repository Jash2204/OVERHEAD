# OVERHEAD — Quick Start (5 minutes)

Thanks for downloading OVERHEAD! Here's how to get the sky on your ceiling.

## You need
- A Windows or Mac computer with Chrome
- Node.js installed (free: nodejs.org — click the green button, install, done)
- A projector connected via HDMI (any model works; point it at the ceiling)

## Setup (one time)
1. Unzip this folder anywhere (e.g. Desktop)
2. **Windows:** double-click `START.bat` — two windows open, then Chrome loads the app
   **Mac/Linux:** open Terminal in this folder and run `node proxy.js`, then in a second Terminal `python3 -m http.server 3000`, then open `http://localhost:3000/OVERHEAD.html` in Chrome
3. Allow location access when Chrome asks (this is how it knows YOUR sky)

## Projecting
1. Press **Win+P** → choose **Extend** (Mac: System Settings → Displays → Extend)
2. In the app sidebar click **OPEN SKY OUTPUT** — a clean black sky window appears
3. Drag that window onto the projector screen
4. Click it once → fullscreen. Lights off. Look up.

## Tips
- **REALISTIC SKY** (on by default) hides horizon clutter and shows vapor trails
- Click any plane for its callsign, altitude and route
- The green pulsing dot is the live ISS — the corner text tells you which way to look
- Everything except planes/ISS works offline — stars and planets are calculated on your machine

Problems? The README.md is full troubleshooting.
